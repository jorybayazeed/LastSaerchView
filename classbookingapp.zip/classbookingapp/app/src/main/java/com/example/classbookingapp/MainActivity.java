package com.example.classbookingapp;


import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Spinner buildingSpinner, floorSpinner;
    private EditText fromTimeEditText, toTimeEditText;
    private TextView selectedDateTextView, resultTextView;
    private Button selectDateButton, bookButton;
    private String selectedBuilding, selectedFloor, selectedDate;
    private Map<String, String> bookings = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        buildingSpinner = findViewById(R.id.buildingSpinner);
        floorSpinner = findViewById(R.id.floorSpinner);
        fromTimeEditText = findViewById(R.id.fromTimeEditText);
        toTimeEditText = findViewById(R.id.toTimeEditText);
        selectedDateTextView = findViewById(R.id.selectedDateTextView);
        selectDateButton = findViewById(R.id.selectDateButton);
        bookButton = findViewById(R.id.bookButton);
        resultTextView = findViewById(R.id.resultTextView);

        selectedDate = "None";

        // Spinner listeners
        buildingSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedBuilding = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        floorSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedFloor = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Date Picker logic
        selectDateButton.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    MainActivity.this,
                    (view, year1, month1, dayOfMonth) -> {
                        selectedDate = dayOfMonth + "/" + (month1 + 1) + "/" + year1;
                        selectedDateTextView.setText("Selected Date: " + selectedDate);
                    },
                    year, month, day);
            datePickerDialog.show();
        });

        // Booking button logic
        bookButton.setOnClickListener(v -> {
            String fromTime = fromTimeEditText.getText().toString().trim();
            String toTime = toTimeEditText.getText().toString().trim();

            if (selectedBuilding == null || selectedFloor == null || selectedDate.equals("None")
                    || fromTime.isEmpty() || toTime.isEmpty()) {
                resultTextView.setText("Please fill all fields.");
                return;
            }

            String bookingKey = selectedBuilding + " " + selectedFloor + " " + selectedDate + " " + fromTime + " to " + toTime;

            if (bookings.containsKey(bookingKey)) {
                resultTextView.setText("Sorry, this slot is already booked.");
            } else {
                bookings.put(bookingKey, "Booked");
                resultTextView.setText("Class booked successfully:\n" + bookingKey);
            }
        });
    }
}
