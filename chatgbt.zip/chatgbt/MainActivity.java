package com.example.myapplication;
// ... other imports
 // Replace with your package name

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Replace with your layout file

        Button openChatbotButton = findViewById(R.id.openChatbotButton);
        openChatbotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openChatbotUrl(); // Replace with your chatbot URL
            }
        });
    }

    private void openChatbotUrl() {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://cdn.botpress.cloud/webchat/v2.2/shareable.html?configUrl=https://files.bpcontent.cloud/2024/10/27/17/20241027173537-2CZZJTNR.json"));
        startActivity(intent);
    }
}