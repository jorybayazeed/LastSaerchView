package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ClassDetailActivity extends AppCompatActivity {
    private DatabaseReference database;
    private TextView classDetails;
    private Button bookButton;
    private Classroom classroom;
    private Floor floor;
    private Section section;
    private Button Cancell_book_button1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_detail);

        database = FirebaseDatabase.getInstance().getReference();

        classDetails = findViewById(R.id.class_details);
        bookButton = findViewById(R.id.book_button);
        Cancell_book_button1= findViewById(R.id.Cancell_book_button);
        String buildingName = getIntent().getStringExtra("buildingName");
        String className = getIntent().getStringExtra("className");

        Building building = getBuildingByName(buildingName);
        if (building != null) {
            for (Floor f : building.getFloors()) {
                for (Section s : f.getSections()) {
                    classroom = getClassroomByName(s, className);
                    if (classroom != null) {
                        floor = f;
                        section = s;
                        classDetails.setText("Building: " + buildingName + "\nFloor: " + floor.getNumber() + "\nSection: " + section.getName() + "\nClass: " + className + "\nStatus: " + classroom.getStatus());
                        break; // Exit the loop once the classroom is found
                    }
                }
                if (classroom != null) {
                    break; // Exit the loop once the classroom is found
                }
            }
        }

        Cancell_book_button1.setOnClickListener(v -> {
            if (classroom != null && "Not Available".equals(classroom.getStatus())) {
                classroom.setStatus(" Available");
                database.child("buildings").child(buildingName).child("floors").child(String.valueOf(floor.getNumber())).child("sections").child(section.getName()).child("classrooms").child(classroom.getName()).setValue(classroom)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(ClassDetailActivity.this, "Class  Cancelled successfully ", Toast.LENGTH_SHORT).show();
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(ClassDetailActivity.this, "Failed to Cancell class. Please try again.", Toast.LENGTH_SHORT).show();
                        });
            } else {
                Toast.makeText(ClassDetailActivity.this, "This class is Cancelled So It Is (Available Now)", Toast.LENGTH_SHORT).show();
            }
        });

        bookButton.setOnClickListener(v -> {
            if (classroom != null && "Available".equals(classroom.getStatus())) {
                classroom.setStatus("Not Available");
                database.child("buildings").child(buildingName).child("floors").child(String.valueOf(floor.getNumber())).child("sections").child(section.getName()).child("classrooms").child(classroom.getName()).setValue(classroom)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(ClassDetailActivity.this, "Class booked successfully!", Toast.LENGTH_SHORT).show();
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(ClassDetailActivity.this, "Failed to book class. Please try again.", Toast.LENGTH_SHORT).show();
                        });
            } else {
                Toast.makeText(ClassDetailActivity.this, "This class is not available", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private Building getBuildingByName(String name) {
        for (Building building : DataInitializer.initializeData()) {
            if (building.getName().equals(name)) {
                return building;
            }
        }
        return null;
    }

    private Classroom getClassroomByName(Section section, String name) {
        for (Classroom classroom : section.getClassrooms()) {
            if (classroom.getName().equals(name)) {
                return classroom;
            }
        }
        return null;
    }
}
