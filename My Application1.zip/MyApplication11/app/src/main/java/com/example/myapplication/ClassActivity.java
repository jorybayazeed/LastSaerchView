package com.example.myapplication;
import android.content.Intent;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class ClassActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> classNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class);

        listView = findViewById(R.id.list_view);
        classNames = new ArrayList<>();

        String buildingName = getIntent().getStringExtra("buildingName");
        int floorNumber = getIntent().getIntExtra("floorNumber", -1);
        Building building = getBuildingByName(buildingName);

        if (building != null) {
            Floor floor = getFloorByNumber(building, floorNumber);
            if (floor != null) {
                for (Section section : floor.getSections()) {
                    for (Classroom classroom : section.getClassrooms()) {
                        classNames.add(classroom.getName());
                    }
                }
            }
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, classNames);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String className = classNames.get(position);
            Intent intent = new Intent(ClassActivity.this, BookingActivity.class);
            intent.putExtra("buildingName", buildingName);
            intent.putExtra("floorNumber", floorNumber);
            intent.putExtra("className", className);
            startActivity(intent);
        });
    }

    private Building getBuildingByName(String name) {
        for (Building building : DataInitializer.initializeData()) {
            if (building.getName().equals(name)) {
                return building;
            }
        }
        return null;
    }

    private Floor getFloorByNumber(Building building, int number) {
        for (Floor floor : building.getFloors()) {
            if (floor.getNumber() == number) {
                return floor;
            }
        }
        return null;
    }
}
