package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class BookingActivity extends AppCompatActivity {
    private Spinner spinnerDate, spinnerStartTime, spinnerEndTime;
    private Button buttonBook, buttonCancel;
    private DatabaseReference database;
    private String buildingName, className;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        spinnerDate = findViewById(R.id.spinner_date);
        spinnerStartTime = findViewById(R.id.spinner_start_time);
        spinnerEndTime = findViewById(R.id.spinner_end_time);
        buttonBook = findViewById(R.id.button_book);
        buttonCancel = findViewById(R.id.button_cancel);

        database = FirebaseDatabase.getInstance().getReference();
        buildingName = getIntent().getStringExtra("buildingName");
        className = getIntent().getStringExtra("className");

        populateDateSpinner();
        populateTimeSpinners();

        buttonBook.setOnClickListener(v -> bookClass());
        buttonCancel.setOnClickListener(v -> cancelBooking());
    }

    private void populateDateSpinner() {
        List<String> dates = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.MONTH, Calendar.DECEMBER);
        for (int i = 1; i <= 30; i++) {
            calendar.set(Calendar.DAY_OF_MONTH, i);
            dates.add(android.text.format.DateFormat.format("yyyy-MM-dd", calendar).toString());
        }
        ArrayAdapter<String> dateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dates);
        dateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDate.setAdapter(dateAdapter);
    }

    private void populateTimeSpinners() {
        List<String> startTimes = new ArrayList<>();
        List<String> endTimes = new ArrayList<>();
        for (int i = 9; i <= 16; i++) {
            startTimes.add(i + ":00 AM");
            if (i != 16) {
                endTimes.add((i + 1) + ":00 AM");
            }
        }
        endTimes.add("4:00 PM");
        ArrayAdapter<String> startTimeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, startTimes);
        startTimeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStartTime.setAdapter(startTimeAdapter);
        ArrayAdapter<String> endTimeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, endTimes);
        endTimeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEndTime.setAdapter(endTimeAdapter);
    }

    private void bookClass() {
        String date = spinnerDate.getSelectedItem().toString();
        String startTime = spinnerStartTime.getSelectedItem().toString();
        String endTime = spinnerEndTime.getSelectedItem().toString();
        DatabaseReference bookingRef = database.child("bookings").child(buildingName).child(className).child(date).child(startTime + "-" + endTime);

        bookingRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult().exists()) {
                Toast.makeText(this, "This class cannot be booked", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(BookingActivity.this, FirstActivity.class);
                startActivity(intent);
            } else {
                bookingRef.setValue("not available").addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "The class is booked successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(BookingActivity.this, BookingConfirmationActivity.class);
                    intent.putExtra("building", buildingName);
                    intent.putExtra("floor", ""); // Add logic to get the floor if needed
                    intent.putExtra("class", className);
                    intent.putExtra("date", date);
                    intent.putExtra("duration_start", startTime);
                    intent.putExtra("duration_end", endTime);
                    startActivity(intent);
                }).addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to book class. Please try again.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(BookingActivity.this, FirstActivity.class);
                    startActivity(intent);
                });
            }
        });
    }

    private void cancelBooking() {
        String date = spinnerDate.getSelectedItem().toString();
        String startTime = spinnerStartTime.getSelectedItem().toString();
        String endTime = spinnerEndTime.getSelectedItem().toString();
        DatabaseReference bookingRef = database.child("bookings").child(buildingName).child(className).child(date).child(startTime + "-" + endTime);

        bookingRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult().exists()) {
                bookingRef.removeValue().addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "The class is cancelled successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(BookingActivity.this, FirstActivity.class);
                    startActivity(intent);
                }).addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to cancel class. Please try again.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(BookingActivity.this, FirstActivity.class);
                    startActivity(intent);
                });
            } else {
                Toast.makeText(this, "You did not book this", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(BookingActivity.this, FirstActivity.class);
                startActivity(intent);
            }
        });
    }
}