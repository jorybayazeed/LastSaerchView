package com.example.myapplication;
import java.util.List;
import java.util.stream.Collectors;
import java.util.List;
import java.util.stream.Collectors;

public class SearchService {
    public List<Building> searchBuildings(List<Building> buildings, String query) {
        return buildings.stream()
                .filter(b -> b.getName().toLowerCase().contains(query.toLowerCase()))
                .collect(Collectors.toList());
    }

    public List<Classroom> searchClassrooms(List<Building> buildings, String query) {
        return buildings.stream()
                .flatMap(b -> b.getFloors().stream())
                .flatMap(f -> f.getSections().stream())
                .flatMap(s -> s.getClassrooms().stream())
                .filter(c -> c.getName().toLowerCase().contains(query.toLowerCase()))
                .collect(Collectors.toList());
    }
}
