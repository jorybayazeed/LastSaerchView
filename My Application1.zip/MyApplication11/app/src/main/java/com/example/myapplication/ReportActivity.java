package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class ReportActivity extends AppCompatActivity {

    private Spinner spinnerBuilding, spinnerFloor, spinnerClass;
    private EditText editTextProblemDescription;
    private Button buttonSubmit;
    private DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        spinnerBuilding = findViewById(R.id.spinner_building);
        spinnerFloor = findViewById(R.id.spinner_floor);
        spinnerClass = findViewById(R.id.spinner_class);
        editTextProblemDescription = findViewById(R.id.edit_text_problem_description);
        buttonSubmit = findViewById(R.id.button_submit);

        database = FirebaseDatabase.getInstance().getReference();

        loadBuildings();

        buttonSubmit.setOnClickListener(v -> submitReport());
    }

    private void loadBuildings() {
        database.child("buildings").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String> buildings = new ArrayList<>();
                for (DataSnapshot buildingSnapshot : snapshot.getChildren()) {
                    String buildingName = buildingSnapshot.getKey();
                    buildings.add(buildingName);
                }
                ArrayAdapter<String> buildingAdapter = new ArrayAdapter<>(ReportActivity.this, android.R.layout.simple_spinner_item, buildings);
                buildingAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerBuilding.setAdapter(buildingAdapter);

                spinnerBuilding.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String selectedBuilding = buildings.get(position);
                        loadFloors(selectedBuilding);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ReportActivity.this, "Failed to load buildings", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadFloors(String building) {
        database.child("buildings").child(building).child("floors").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String> floors = new ArrayList<>();
                for (DataSnapshot floorSnapshot : snapshot.getChildren()) {
                    Long floorNumber = floorSnapshot.child("number").getValue(Long.class);
                    if (floorNumber != null) {
                        floors.add(String.valueOf(floorNumber));
                    }
                }
                ArrayAdapter<String> floorAdapter = new ArrayAdapter<>(ReportActivity.this, android.R.layout.simple_spinner_item, floors);
                floorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerFloor.setAdapter(floorAdapter);

                spinnerFloor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String selectedFloor = floors.get(position);
                        loadClasses(building, selectedFloor);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ReportActivity.this, "Failed to load floors", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadClasses(String building, String floor) {
        database.child("buildings").child(building).child("floors").orderByChild("number").equalTo(Long.parseLong(floor)).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String> classes = new ArrayList<>();
                for (DataSnapshot floorSnapshot : snapshot.getChildren()) {
                    for (DataSnapshot sectionSnapshot : floorSnapshot.child("sections").getChildren()) {
                        for (DataSnapshot classSnapshot : sectionSnapshot.child("classrooms").getChildren()) {
                            String className = classSnapshot.child("name").getValue(String.class);
                            classes.add(className);
                        }
                    }
                }
                ArrayAdapter<String> classAdapter = new ArrayAdapter<>(ReportActivity.this, android.R.layout.simple_spinner_item, classes);
                classAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerClass.setAdapter(classAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ReportActivity.this, "Failed to load classes", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void submitReport() {
        String building = spinnerBuilding.getSelectedItem().toString();
        String floor = spinnerFloor.getSelectedItem().toString();
        String classNumber = spinnerClass.getSelectedItem().toString();
        String problemDescription = editTextProblemDescription.getText().toString();

        DatabaseReference reportRef = database.child("reports").child(building).child(floor).child(classNumber);

        reportRef.setValue(problemDescription).addOnSuccessListener(aVoid -> {
            Toast.makeText(this, "Report submitted successfully", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ReportActivity.this, FirstActivity.class);
            startActivity(intent);
        }).addOnFailureListener(e -> {
            Toast.makeText(this, "Failed to submit report. Please try again.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ReportActivity.this, FirstActivity.class);
            startActivity(intent);
        });
    }
}
