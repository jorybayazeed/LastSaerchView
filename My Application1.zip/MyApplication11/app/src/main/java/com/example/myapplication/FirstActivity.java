package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.List;

public class FirstActivity extends AppCompatActivity {
    private DatabaseReference database;
    private ListView listView;
    private SearchView searchView;
    private ArrayAdapter<String> adapter;
    private List<Building> buildings;
    private List<String> searchResults;
    private ImageButton chatImage;
    private ImageView image1;
    private ImageView image2;
    private ImageView image3;
    private ImageButton image4;
    private Button Book_Class;
    private Button Report;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first); // Ensure this matches your XML layout file name

        // Initialize Firebase
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        database = firebaseDatabase.getReference();

        // Initialize views
        listView = findViewById(R.id.list_view);
        searchView = findViewById(R.id.search_view);
        chatImage = findViewById(R.id.imagechatBot);
        image1 = findViewById(R.id.image_profile);
        image2 = findViewById(R.id.image_home);
        image3 = findViewById(R.id.image_contact);
        image4 = findViewById(R.id.imageButton);
        Book_Class=findViewById(R.id.button1);
        Report=findViewById(R.id.button2);
        // Initialize data
        buildings = DataInitializer.initializeData();
        searchResults = new ArrayList<>();

        // Write all data to Firebase
        for (Building building : buildings) {
            database.child("buildings").child(building.getName()).setValue(building);
        }

        // Set up adapter
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, searchResults);
        listView.setAdapter(adapter);

        // Set up search view
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchResults.clear();
                for (Building building : buildings) {
                    if (building.getName().toLowerCase().contains(newText.toLowerCase())) {
                        searchResults.add(building.getName());
                    }
                    for (Floor floor : building.getFloors()) {
                        for (Section section : floor.getSections()) {
                            for (Classroom classroom : section.getClassrooms()) {
                                if (classroom.getName().toLowerCase().contains(newText.toLowerCase())) {
                                    searchResults.add(classroom.getName() + " (" + building.getName() + ")");
                                }
                            }
                        }
                    }
                }
                adapter.notifyDataSetChanged();
                return false;
            }
        });

        Book_Class.setOnClickListener(v ->{
            Intent intent = new Intent(FirstActivity.this, MainActivity.class);
            startActivity(intent);
                });
        Report.setOnClickListener(v ->{
            Intent intent = new Intent(FirstActivity.this, ReportActivity.class);
            startActivity(intent);
        });
        // Set up search view click listener to navigate to MainActivity
        searchView.setOnSearchClickListener(v -> {
            Intent intent = new Intent(FirstActivity.this, MainActivity.class);
            startActivity(intent);
        });

        // Set up list view item click listener
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(FirstActivity.this, MainActivity.class);
            startActivity(intent);
        });

        // Set up onClick listeners for buttons and image views
        chatImage.setOnClickListener(v -> {
            // Handle chat image click
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://cdn.botpress.cloud/webchat/v2.2/shareable.html?configUrl=https://files.bpcontent.cloud/2024/10/27/17/20241027173537-2CZZJTNR.json"));
            startActivity(intent);
        });

        image1.setOnClickListener(v -> {
            // Handle profile image click
            Intent intent = new Intent(FirstActivity.this, Profile.class);
            startActivity(intent);
        });

        image2.setOnClickListener(v -> {
            // Handle home image click
            // Avoid starting the same activity
            // Intent intent = new Intent(FirstActivity.this, FirstActivity.class);
            // startActivity(intent);
        });

        image3.setOnClickListener(v -> {
            // Handle contact image click
            Intent intent = new Intent(FirstActivity.this,contactIcon.class);
            startActivity(intent);
        });

        image4.setOnClickListener(v -> {
            // Handle image button click
            Intent intent = new Intent(FirstActivity.this, MapsActivity.class);
            startActivity(intent);
        });
    }
}
