package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BookingConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_confirmation);

        TextView textBuilding = findViewById(R.id.text_building);
        TextView textFloor = findViewById(R.id.text_floor);
        TextView textClass = findViewById(R.id.text_class);
        TextView textDate = findViewById(R.id.text_date);
        TextView textDurationStart = findViewById(R.id.text_duration_start);
        TextView textDurationEnd = findViewById(R.id.text_duration_end);
        Button buttonOk = findViewById(R.id.button_ok);

        Intent intent = getIntent();
        String building = intent.getStringExtra("building");
        String floor = intent.getStringExtra("floor");
        String className = intent.getStringExtra("class");
        String date = intent.getStringExtra("date");
        String durationStart = intent.getStringExtra("duration_start");
        String durationEnd = intent.getStringExtra("duration_end");

        textBuilding.setText("Building: " + building);
        textFloor.setText("Floor: " + floor);
        textClass.setText("Class: " + className);
        textDate.setText("Date: " + date);
        textDurationStart.setText("Start Time: " + durationStart);
        textDurationEnd.setText("End Time: " + durationEnd);

        buttonOk.setOnClickListener(v -> {
            Intent okIntent = new Intent(BookingConfirmationActivity.this, FirstActivity.class);
            startActivity(okIntent);
        });
    }
}